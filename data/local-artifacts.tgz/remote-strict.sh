#!/bin/bash
# Strict-invalidation A/B on the reshaped kernel: msk=128 vs msk=2048.
set -u
KVER=$(uname -r)
case "$KVER" in *iovaopt*) ;; *) echo "FATAL wrong kernel $KVER"; exit 1;; esac
grep -q 'iommu.strict=1' /proc/cmdline || { echo "FATAL not strict boot"; exit 1; }
OUT=/root/iova/results; LOG=$OUT/strict.log; : > $LOG
say() { echo "$@" | tee -a "$LOG"; }

TESTDEV=""
for ns in /sys/block/nvme*n1; do
	d=$(basename "$ns")
	[ "$(cat "$ns"/size)" -gt 3000000000 ] || continue
	lsblk -n "/dev/$d" | grep -q part && continue
	findmnt -S "/dev/$d" >/dev/null && continue
	s=$(cat /sys/block/$d/device/serial | tr -d ' ')
	if [ -z "$TESTDEV" ] || [ "$s" \< "$TESTSER" ]; then TESTDEV=$d; TESTSER=$s; fi
done
PCIDEV=$(readlink -f /sys/block/$TESTDEV/device/device | grep -oE '[0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-9]' | tail -1)
for g in /sys/kernel/iommu_groups/*/devices/$PCIDEV; do
	[ -e "$g" ] && say "GATE iommu_group_type=$(cat $(dirname $(dirname $g))/type)"
done
say "GATE kver=$KVER testdev=$TESTDEV max_hw=$(cat /sys/block/$TESTDEV/queue/max_hw_sectors_kb)"
echo 2048 > /proc/sys/vm/nr_hugepages
MSKF=/sys/block/$TESTDEV/queue/max_sectors_kb

run_case() {
	local phase=$1 name=$2 rep=$3; shift 3
	local json=/tmp/st-$phase-$name-r$rep.json
	fio --name=$name --filename=/dev/$TESTDEV --direct=1 --ioengine=io_uring \
	    --time_based --runtime=20 --ramp_time=3 --norandommap --randrepeat=0 \
	    --group_reporting --size=100g --output-format=json --output=$json \
	    "$@" >/dev/null 2>&1
	python3 - $json "$phase.$name" $rep <<'EOF' | tee -a "$LOG"
import json, sys
j = json.load(open(sys.argv[1])); job = j["jobs"][0]; r = job["read"]
print("RESULT case=%s rep=%s bw_MiBps=%.0f iops=%.0f p99_us=%.0f sys=%.1f" % (
    sys.argv[2], sys.argv[3], r["bw_bytes"]/(1<<20), r["iops"],
    r["clat_ns"]["percentile"]["99.000000"]/1e3, job["usr_cpu"]+job["sys_cpu"]))
EOF
}

for msk in 128 2048; do
	echo $msk > "$MSKF"
	say "PHASE strict msk=$(cat $MSKF)"
	for rep in 1 2 3; do
		run_case s$msk seq2m_qd8 $rep --bs=2M --rw=read --iodepth=8 --numjobs=1 --iomem=mmaphuge
		run_case s$msk rand512k_qd32 $rep --bs=512k --rw=randread --iodepth=32 --numjobs=1 --iomem=mmaphuge
	done
done
echo 128 > "$MSKF"
say "STRICT_DONE"
