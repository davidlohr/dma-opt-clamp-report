#!/bin/bash
# Cross-device QoS: opt-in 2MB stream on drive A, 4K latency job on drive B.
set -u
KVER=$(uname -r)
case "$KVER" in *iovaopt*) ;; *) echo "FATAL wrong kernel $KVER"; exit 1;; esac
OUT=/root/iova/results; LOG=$OUT/qoscross.log; : > $LOG
say() { echo "$@" | tee -a "$LOG"; }

mapfile -t DRV < <(for ns in /sys/block/nvme*n1; do
	d=$(basename "$ns")
	[ "$(cat "$ns"/size)" -gt 3000000000 ] || continue
	lsblk -n "/dev/$d" | grep -q part && continue
	findmnt -S "/dev/$d" >/dev/null && continue
	echo "$(cat /sys/block/$d/device/serial | tr -d ' ') $d"
done | sort | awk '{print $2}')
A=${DRV[0]}; B=${DRV[1]:-}
[ -n "$B" ] || { say "FATAL need two blank drives"; exit 1; }
say "GATE kver=$KVER devA=$A devB=$B"

MARK="/root/iova/.precond-$(cat /sys/block/$B/device/serial | tr -d ' ')"
if [ ! -f "$MARK" ]; then
	say "PRECONDITION devB $B"
	fio --name=pre --filename=/dev/$B --rw=write --bs=1M --iodepth=32 \
	    --direct=1 --size=100g --ioengine=io_uring --output-format=terse \
	    >/dev/null && touch "$MARK"
fi
echo 2048 > /proc/sys/vm/nr_hugepages
echo 2048 > /sys/block/$A/queue/max_sectors_kb
say "GATE devA_msk=$(cat /sys/block/$A/queue/max_sectors_kb) devB_msk=$(cat /sys/block/$B/queue/max_sectors_kb)"

for rep in 1 2 3; do
	json=$OUT/qoscross-r$rep.json
	fio --direct=1 --ioengine=io_uring --time_based --runtime=20 \
	    --ramp_time=3 --norandommap --randrepeat=0 --size=100g \
	    --output-format=json --output=$json \
	    --name=qos_big --filename=/dev/$A --bs=2M --rw=randread --iodepth=8 --numjobs=4 --iomem=mmaphuge \
	    --name=qos_small --filename=/dev/$B --bs=4k --rw=randread --iodepth=16 --numjobs=2 \
	    >/dev/null 2>&1
	python3 - $json $rep <<'EOF' | tee -a "$LOG"
import json, sys
j = json.load(open(sys.argv[1]))
for job in j["jobs"]:
    r = job["read"]
    if r["io_bytes"] == 0: continue
    print("RESULT case=qoscross job=%s rep=%s bw_MiBps=%.0f iops=%.0f "
          "p50_us=%.0f p99_us=%.0f" % (job["jobname"], sys.argv[2],
          r["bw_bytes"]/(1<<20), r["iops"],
          r["clat_ns"]["percentile"]["50.000000"]/1e3,
          r["clat_ns"]["percentile"]["99.000000"]/1e3))
EOF
done
echo 128 > /sys/block/$A/queue/max_sectors_kb
say "QOSCROSS_DONE"
