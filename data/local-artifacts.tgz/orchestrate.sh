#!/bin/bash
# Boot/bench loop from the workstation: for each requested kernel tag,
# grub-reboot one-shot into it, wait for SSH + uname match, run bench,
# pull the log. Usage: orchestrate.sh iovabase iovapatch iovabase iovapatch
set -u
H=ubuntu@160.202.129.137
SP=/tmp/claude-1000/-home-dave-code-tip/0431dcec-b953-4044-849e-16e85bcdf84f/scratchpad
mkdir -p "$SP/results"
S() { ssh -o BatchMode=yes -o ConnectTimeout=10 "$H" "$@"; }

for tag in "$@"; do
	echo "=== boot $tag $(date +%H:%M:%S)"
	entry=$(S "sudo grep -oP \"menuentry '\\K[^']+(?=')\" /boot/grub/grub.cfg | grep -- \"-$tag\" | grep -v recovery | head -1")
	[ -n "$entry" ] || { echo "FATAL: no grub entry for $tag"; exit 1; }
	S "sudo grub-reboot 'Advanced options for Ubuntu>$entry' && sudo reboot" || true
	sleep 60
	for i in $(seq 1 40); do
		kv=$(S 'uname -r' 2>/dev/null) && [ -n "$kv" ] && break
		sleep 15
	done
	kv=$(S 'uname -r' 2>/dev/null)
	case "$kv" in
	*"$tag"*) echo "BOOTED $kv" ;;
	*) echo "WRONG_KERNEL got='$kv' want=*$tag* — aborting"; exit 1 ;;
	esac
	S 'sudo /root/iova/remote-bench.sh' | tail -30
	S "sudo cat /root/iova/results/$kv.log" > "$SP/results/$kv-boot$(date +%s).log"
done
echo ORCHESTRATE_DONE
