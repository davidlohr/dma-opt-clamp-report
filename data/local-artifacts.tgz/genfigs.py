#!/usr/bin/env python3
"""Generate SVG figures for the DMA-optimal clamp report (validated palette)."""
import os

OUT = "/home/dave/code/tip/dma-opt-clamp-figs"
os.makedirs(OUT, exist_ok=True)

SURF, BORDER, GRID = "#fcfcfb", "#e0dedb", "#eceae6"
INK, INK2 = "#0b0b0b", "#52514e"
BLUE, ORANGE, AQUA, YELLOW = "#2a78d6", "#eb6834", "#1baf7a", "#eda100"
FONT = "system-ui, -apple-system, sans-serif"

def bar_path(x, y, w, h, r=4):
    if w <= 2 * r:
        return f'<rect x="{x:.1f}" y="{y:.1f}" width="{max(w,1):.1f}" height="{h}" fill-opacity="1"'
    return (f'<path d="M{x:.1f},{y:.1f} h{w-r:.1f} a{r},{r} 0 0 1 {r},{r} '
            f'v{h-2*r} a{r},{r} 0 0 1 -{r},{r} h-{w-r:.1f} z"')

def svg_open(w, h, title):
    return [f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" '
            f'viewBox="0 0 {w} {h}" font-family="{FONT}">',
            f'<rect width="{w}" height="{h}" fill="{SURF}" stroke="{BORDER}"/>',
            f'<text x="20" y="28" font-size="14" font-weight="600" fill="{INK}">{title}</text>']

def hbar_chart(fname, title, cases, series, xmax, xlab, ticks, w=760,
               annotate=None, textures=None, bar_colors=None):
    """cases: [label,...]; series: [(name,color,[vals]),...]"""
    n, s = len(cases), len(series)
    bh, gap_in, gap_out = 15, 2, 14
    row_h = s * bh + (s - 1) * gap_in + gap_out
    left, right, top = 190, 90, 62
    h = top + n * row_h + 34
    plot_w = w - left - right
    o = svg_open(w, h, title)
    o.append('<defs><pattern id="tex" width="6" height="6" patternUnits="userSpaceOnUse" '
             'patternTransform="rotate(45)"><rect width="6" height="6" fill-opacity="0"/>'
             f'<line x1="0" y1="0" x2="0" y2="6" stroke="{SURF}" stroke-width="2.5"/></pattern></defs>')
    # legend (only if >1 series)
    if s > 1:
        lx = left
        for name, color, _ in series:
            o.append(f'<rect x="{lx}" y="40" width="10" height="10" rx="2" fill="{color}"/>')
            o.append(f'<text x="{lx+15}" y="49" font-size="11" fill="{INK2}">{name}</text>')
            lx += 15 + 7.2 * len(name) + 22
    # grid + x labels
    for t in ticks:
        gx = left + plot_w * t / xmax
        o.append(f'<line x1="{gx:.1f}" y1="{top-6}" x2="{gx:.1f}" y2="{h-30}" stroke="{GRID}"/>')
        o.append(f'<text x="{gx:.1f}" y="{h-14}" font-size="10" fill="{INK2}" '
                 f'text-anchor="middle">{t:,}</text>')
    o.append(f'<text x="{left+plot_w/2:.0f}" y="{h-2}" font-size="10" fill="{INK2}" '
             f'text-anchor="middle">{xlab}</text>')
    for i, case in enumerate(cases):
        y0 = top + i * row_h
        o.append(f'<text x="{left-8}" y="{y0 + (s*bh+(s-1)*gap_in)/2 + 4}" font-size="11" '
                 f'fill="{INK}" text-anchor="end">{case}</text>')
        for j, (name, color, vals) in enumerate(series):
            v = vals[i]
            bw_ = plot_w * v / xmax
            yy = y0 + j * (bh + gap_in)
            tex = textures and textures.get((i, j))
            c = bar_colors[i] if bar_colors else color
            o.append(bar_path(left, yy, bw_, bh) + f' fill="{c}"/>')
            if tex:
                o.append(bar_path(left, yy, bw_, bh) + ' fill="url(#tex)"/>')
            label = f'{v:,.0f}' if v >= 100 else (f'{v:.2f}' if v >= 1 else f'{v:g}')
            o.append(f'<text x="{left+bw_+6:.1f}" y="{yy+bh-3.5}" font-size="10.5" '
                     f'fill="{INK2}">{label}</text>')
            if annotate and (i, j) in annotate:
                ax = left + bw_ + 6 + 7 * len(label) + 8
                o.append(f'<text x="{ax:.1f}" y="{yy+bh-3.5}" font-size="10.5" '
                         f'font-weight="600" fill="{INK}">{annotate[(i,j)]}</text>')
    # baseline
    o.append(f'<line x1="{left}" y1="{top-6}" x2="{left}" y2="{h-30}" stroke="{INK2}"/>')
    o.append('</svg>')
    open(f"{OUT}/{fname}", "w").write("\n".join(o))

# fig1: bare metal bandwidth
hbar_chart("fig1-baremetal-bw.svg",
    "Bare metal, translated IOMMU: read bandwidth (MiB/s, medians n=6)",
    ["seq 2MB QD8", "seq 2MB QD32×4", "rand 1MB QD16", "rand 512K QD32",
     "rand 128K QD32 (guard)"],
    [("base (128KB cap)", BLUE, [6607, 6676, 6608, 6607, 6453]),
     ("358580dd598b (2MB)", ORANGE, [6083, 6132, 6549, 6612, 6455])],
    7000, "MiB/s", [0, 2000, 4000, 6000],
    annotate={(0, 1): "−7.9%", (1, 1): "−8.1%"})

# fig2: interrupts per GB
hbar_chart("fig2-irq-per-gb.svg",
    "Completion cost: NVMe interrupts per GiB read (medians n=6)",
    ["seq 2MB QD8", "seq 2MB QD32×4", "rand 1MB QD16", "rand 512K QD32",
     "rand 128K QD32 (guard)"],
    [("base (128KB cap)", BLUE, [9362, 9379, 9345, 9332, 9306]),
     ("358580dd598b (2MB)", ORANGE, [589, 589, 1175, 2353, 9305])],
    10500, "interrupts / GiB", [0, 2500, 5000, 7500, 10000],
    annotate={(0, 1): "−93.7%", (3, 1): "−74.8%"})

# fig3: QoS p99
hbar_chart("fig3-qos-p99.svg",
    "4K reader p99 latency vs a 2MB restore storm (ms)",
    ["base, shared device", "2MB requests, shared device",
     "2MB requests, separate device"],
    [("", ORANGE, [4.62, 11.08, 0.165])],
    12, "p99 (ms) — lower is better", [0, 3, 6, 9, 12],
    textures={(2, 0): True},
    annotate={(1, 0): "+140%", (2, 0): "−96% vs base"},
    bar_colors=[BLUE, ORANGE, ORANGE])

# fig4: guest matrix
hbar_chart("fig4-guest-seq2m.svg",
    "KVM guest (emulated VT-d, RAM-backed NVMe): seq 2MB QD8 (MiB/s)",
    ["base", "reshaped, default", "reshaped, opt-in", "original patch"],
    [("", BLUE, [5782, 5740, 27258, 27354])],
    30000, "MiB/s", [0, 10000, 20000, 30000],
    annotate={(2, 0): "+371%"},
    bar_colors=[BLUE, AQUA, YELLOW, ORANGE])

print("generated:", sorted(os.listdir(OUT)))
