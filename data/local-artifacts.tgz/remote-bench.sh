#!/bin/bash
# Per-boot benchmark: verify gates, precondition test drive once, run the
# fio matrix 3x, emit parseable RESULT lines. Read/write ONLY on the chosen
# blank non-OS 1.9TB NVMe (write = one-time precondition fill).
set -u
KVER=$(uname -r)
OUT=/root/iova/results
mkdir -p "$OUT"
LOG="$OUT/$KVER.log"
: > "$LOG"
say() { echo "$@" | tee -a "$LOG"; }

# ---- gates ---------------------------------------------------------------
say "GATE kver=$KVER"
dmesg | grep -iE 'AMD-Vi|AMD IOMMUv?2|iommu.*(enabled|disabled)' | head -5 | tee -a "$LOG"

# pick test drive: largest-model NVMe namespaces with no partitions, holders,
# or mounts; stable choice by serial sort
declare -a CAND=()
for ns in /sys/block/nvme*n1; do
	d=$(basename "$ns")
	[ "$(cat "$ns"/size)" -gt 3000000000 ] || continue   # >1.5TB in 512B sectors
	lsblk -n "/dev/$d" | grep -q part && continue
	[ -n "$(ls "$ns"/holders 2>/dev/null)" ] && continue
	findmnt -S "/dev/$d" >/dev/null && continue
	CAND+=("$d $(cat /sys/block/$d/device/serial 2>/dev/null | tr -d ' ')")
done
TESTDEV=$(printf '%s\n' "${CAND[@]}" | sort -k2 | head -1 | awk '{print $1}')
[ -n "$TESTDEV" ] || { say "FATAL no blank test drive"; exit 1; }
SERIAL=$(printf '%s\n' "${CAND[@]}" | sort -k2 | head -1 | awk '{print $2}')
say "GATE testdev=$TESTDEV serial=$SERIAL"
say "GATE max_hw_sectors_kb=$(cat /sys/block/$TESTDEV/queue/max_hw_sectors_kb) max_sectors_kb=$(cat /sys/block/$TESTDEV/queue/max_sectors_kb)"
say "GATE mdts=$(nvme id-ctrl /dev/${TESTDEV%n1} 2>/dev/null | awk '/^mdts/{print $3}')"
# iommu domain type for the test device
PCIDEV=$(readlink -f /sys/block/$TESTDEV/device/device 2>/dev/null | grep -oE '[0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-9]' | tail -1)
for g in /sys/kernel/iommu_groups/*/devices/$PCIDEV; do
	[ -e "$g" ] && say "GATE iommu_group_type=$(cat $(dirname $(dirname $g))/type)"
done

# hugepages for mmaphuge buffers
echo 2048 > /proc/sys/vm/nr_hugepages
say "GATE hugepages=$(cat /proc/sys/vm/nr_hugepages)"

# ---- precondition (once per drive, ever) ----------------------------------
MARK="/root/iova/.precond-$SERIAL"
if [ ! -f "$MARK" ]; then
	say "PRECONDITION writing 100GiB to /dev/$TESTDEV"
	fio --name=precond --filename=/dev/$TESTDEV --rw=write --bs=1M \
	    --iodepth=32 --direct=1 --size=100g --ioengine=io_uring \
	    --output-format=terse >/dev/null && touch "$MARK"
fi

# ---- matrix ----------------------------------------------------------------
irq_sum() { awk '/nvme/{for(i=2;i<NF-2;i++) s+=$i} END{print s+0}' /proc/interrupts; }

run_case() {
	local name=$1 rep=$2; shift 2
	local json="$OUT/$KVER-$name-r$rep.json"
	local i0 i1
	i0=$(irq_sum)
	fio --name="$name" --filename=/dev/$TESTDEV --direct=1 \
	    --ioengine=io_uring --time_based --runtime=20 --ramp_time=3 \
	    --norandommap --randrepeat=0 --group_reporting --size=100g \
	    --output-format=json --output="$json" "$@" >/dev/null 2>&1
	i1=$(irq_sum)
	python3 - "$json" "$name" "$rep" "$((i1-i0))" <<'EOF' | tee -a "$LOG"
import json, sys
j = json.load(open(sys.argv[1]))
job = j["jobs"][0]
r = job["read"]
gb = r["io_bytes"] / (1 << 30)
irqs = int(sys.argv[4])
print("RESULT case=%s rep=%s bw_MiBps=%.0f iops=%.0f p50_us=%.0f p99_us=%.0f "
      "usr=%.1f sys=%.1f irq_per_gb=%.0f" % (
      sys.argv[2], sys.argv[3], r["bw_bytes"] / (1 << 20), r["iops"],
      r["clat_ns"]["percentile"]["50.000000"] / 1e3,
      r["clat_ns"]["percentile"]["99.000000"] / 1e3,
      job["usr_cpu"], job["sys_cpu"], irqs / gb if gb else 0))
EOF
}

for rep in 1 2 3; do
	run_case seq2m_qd8      $rep --bs=2M   --rw=read     --iodepth=8  --numjobs=1 --iomem=mmaphuge
	run_case seq2m_qd32x4   $rep --bs=2M   --rw=read     --iodepth=32 --numjobs=4 --offset_increment=25g --iomem=mmaphuge
	run_case rand1m_qd16    $rep --bs=1M   --rw=randread --iodepth=16 --numjobs=1 --iomem=mmaphuge
	run_case rand512k_qd32  $rep --bs=512k --rw=randread --iodepth=32 --numjobs=1 --iomem=mmaphuge
	run_case rand128k_qd32  $rep --bs=128k --rw=randread --iodepth=32 --numjobs=1
	run_case rand4k_qd32x8  $rep --bs=4k   --rw=randread --iodepth=32 --numjobs=8
done

dmesg | grep -icE 'WARNING:|BUG:|Oops|Call Trace|DMAR|AMD-Vi.*(fault|error)' \
	| xargs -I{} say "DMESG_SCAN: {} findings"
say "BENCH_DONE kver=$KVER"
