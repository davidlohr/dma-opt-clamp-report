#!/bin/bash
# KV-cache-shaped addon matrix: extent-restore latency, prefix scan,
# QoS interference (large restores vs 4K noise), eviction dump.
# Same drive-selection and safety rules as remote-bench.sh.
set -u
KVER=$(uname -r)
OUT=/root/iova/results
mkdir -p "$OUT"
LOG="$OUT/$KVER-kv.log"
: > "$LOG"
say() { echo "$@" | tee -a "$LOG"; }

say "GATE kver=$KVER"
declare -a CAND=()
for ns in /sys/block/nvme*n1; do
	d=$(basename "$ns")
	[ "$(cat "$ns"/size)" -gt 3000000000 ] || continue
	lsblk -n "/dev/$d" | grep -q part && continue
	[ -n "$(ls "$ns"/holders 2>/dev/null)" ] && continue
	findmnt -S "/dev/$d" >/dev/null && continue
	CAND+=("$d $(cat /sys/block/$d/device/serial 2>/dev/null | tr -d ' ')")
done
TESTDEV=$(printf '%s\n' "${CAND[@]}" | sort -k2 | head -1 | awk '{print $1}')
[ -n "$TESTDEV" ] || { say "FATAL no blank test drive"; exit 1; }
say "GATE testdev=$TESTDEV max_hw_sectors_kb=$(cat /sys/block/$TESTDEV/queue/max_hw_sectors_kb)"
echo 2048 > /proc/sys/vm/nr_hugepages

parse() { # json case rep -> RESULT line per job
	python3 - "$@" <<'EOF'
import json, sys
j = json.load(open(sys.argv[1]))
for job in j["jobs"]:
    for d in ("read", "write"):
        r = job[d]
        if r["io_bytes"] == 0:
            continue
        print("RESULT case=%s job=%s dir=%s rep=%s bw_MiBps=%.0f iops=%.0f "
              "p50_us=%.0f p99_us=%.0f usr=%.1f sys=%.1f" % (
              sys.argv[2], job["jobname"], d, sys.argv[3],
              r["bw_bytes"] / (1 << 20), r["iops"],
              r["clat_ns"]["percentile"]["50.000000"] / 1e3,
              r["clat_ns"]["percentile"]["99.000000"] / 1e3,
              job["usr_cpu"], job["sys_cpu"]))
EOF
}

G="--filename=/dev/$TESTDEV --direct=1 --ioengine=io_uring --time_based
   --runtime=20 --ramp_time=3 --norandommap --randrepeat=0 --size=100g
   --output-format=json"

for rep in 1 2 3; do
	f="$OUT/$KVER-kv_restore-r$rep.json"
	fio $G --output="$f" --name=kv_restore --bs=2M --rw=randread \
	    --iodepth=2 --numjobs=16 --iomem=mmaphuge --group_reporting >/dev/null 2>&1
	parse "$f" kv_restore $rep | tee -a "$LOG"

	f="$OUT/$KVER-kv_prefix-r$rep.json"
	fio $G --output="$f" --name=kv_prefix --bs=1M --rw=read \
	    --iodepth=4 --numjobs=8 --offset_increment=12g --iomem=mmaphuge \
	    --group_reporting >/dev/null 2>&1
	parse "$f" kv_prefix $rep | tee -a "$LOG"

	f="$OUT/$KVER-kv_qos-r$rep.json"
	fio $G --output="$f" \
	    --name=qos_big --bs=2M --rw=randread --iodepth=8 --numjobs=4 --iomem=mmaphuge \
	    --name=qos_small --bs=4k --rw=randread --iodepth=16 --numjobs=2 \
	    >/dev/null 2>&1
	parse "$f" kv_qos $rep | tee -a "$LOG"

	f="$OUT/$KVER-kv_evict-r$rep.json"
	fio $G --output="$f" --name=kv_evict --bs=2M --rw=write \
	    --iodepth=8 --numjobs=4 --offset_increment=25g --iomem=mmaphuge \
	    --group_reporting >/dev/null 2>&1
	parse "$f" kv_evict $rep | tee -a "$LOG"
done
say "BENCH_KV_DONE kver=$KVER"
