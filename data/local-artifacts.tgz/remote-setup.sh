#!/bin/bash
# One-time setup on the Latitude box: unpack source, build kernel B (base,
# parent of 358580dd598b) and kernel A (patched), install both, prep grub.
set -euxo pipefail
cd /root/iova

export DEBIAN_FRONTEND=noninteractive
apt-get -qq update
apt-get -qq install -y build-essential flex bison libssl-dev libelf-dev bc \
	zstd fio nvme-cli linux-headers-$(uname -r) >/dev/null

mkdir -p linux && cd linux
if [ ! -f Makefile ]; then
	tar --use-compress-program=unzstd -xf ../linux-base.tar.zst
fi

# Config: distro config minus debug-info/BTF/keys; IOMMU translated-lazy;
# root-critical storage built-in so boot never depends on initramfs contents
# (lesson from a prior localmodconfig initramfs failure).
cp "/boot/config-$(uname -r)" .config
scripts/config -d DEBUG_INFO -d DEBUG_INFO_DWARF_TOOLCHAIN_DEFAULT \
	-d DEBUG_INFO_DWARF4 -d DEBUG_INFO_DWARF5 -e DEBUG_INFO_NONE \
	-d DEBUG_INFO_BTF \
	--set-str SYSTEM_TRUSTED_KEYS "" --set-str SYSTEM_REVOCATION_KEYS "" \
	-e IOMMU_SUPPORT -e AMD_IOMMU -e IRQ_REMAP \
	-e IOMMU_DEFAULT_DMA_LAZY -d IOMMU_DEFAULT_DMA_STRICT -d IOMMU_DEFAULT_PASSTHROUGH \
	-e NVME_CORE -e BLK_DEV_NVME -e EXT4_FS -e VFAT_FS
# keep md/dm bootable if the OS uses them
if grep -q active /proc/mdstat 2>/dev/null; then
	scripts/config -e MD -e BLK_DEV_MD -e MD_RAID0 -e MD_RAID1
fi
if [ -d /dev/mapper ] && dmsetup ls 2>/dev/null | grep -qv 'No devices'; then
	scripts/config -e DM_MOD -e DM_CRYPT -e DM_MIRROR
fi
yes '' | make -s localmodconfig >/dev/null 2>&1 || true
# re-assert after localmodconfig (it can drop forced options' dependents)
scripts/config -e NVME_CORE -e BLK_DEV_NVME -e EXT4_FS -e VFAT_FS \
	-e IOMMU_SUPPORT -e AMD_IOMMU -e IRQ_REMAP -e IOMMU_DEFAULT_DMA_LAZY
make -s olddefconfig

grep -E '^CONFIG_(AMD_IOMMU|BLK_DEV_NVME|NVME_CORE|EXT4_FS|IOMMU_DEFAULT_DMA_LAZY)=' .config

# Kernel B: base (358580dd598b~1)
make -s -j"$(nproc)" LOCALVERSION=-iovabase
make -s -j"$(nproc)" LOCALVERSION=-iovabase modules_install install

# Kernel A: base + the one patch
patch -p1 < ../0001-nvme-pci-lift-dma-opt-cap.patch
make -s -j"$(nproc)" LOCALVERSION=-iovapatch
make -s -j"$(nproc)" LOCALVERSION=-iovapatch modules_install install

# grub: keep distro kernel the default (safe fallback), one-shot boots via
# grub-reboot; translated IOMMU on all entries.
sed -i 's/^GRUB_DEFAULT=.*/GRUB_DEFAULT=saved/' /etc/default/grub
grep -q GRUB_CMDLINE_LINUX= /etc/default/grub
sed -i 's/^GRUB_CMDLINE_LINUX="\(.*\)"/GRUB_CMDLINE_LINUX="\1 amd_iommu=on iommu.passthrough=0"/' /etc/default/grub
update-grub
grub-set-default 0
grep -oP "menuentry '\K[^']+(?=')" /boot/grub/grub.cfg | grep -i iova || true
echo SETUP_DONE
