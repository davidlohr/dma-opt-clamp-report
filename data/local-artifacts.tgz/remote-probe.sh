#!/bin/bash
# Isolation probe on the PATCHED kernel (max_hw=2048):
#  A) max_sectors_kb=128 -> does large-block bw return to base-kernel levels?
#     (isolates request size from everything else in the mapping path)
#  B) QD sweep at 2MB with max_sectors_kb=2048 -> does depth recover the loss?
set -u
KVER=$(uname -r)
case "$KVER" in *iovapatch*) ;; *) echo "FATAL wrong kernel $KVER"; exit 1;; esac
OUT=/root/iova/results
LOG="$OUT/$KVER-probe.log"
: > "$LOG"
say() { echo "$@" | tee -a "$LOG"; }

TESTDEV=""
for ns in /sys/block/nvme*n1; do
	d=$(basename "$ns")
	[ "$(cat "$ns"/size)" -gt 3000000000 ] || continue
	lsblk -n "/dev/$d" | grep -q part && continue
	findmnt -S "/dev/$d" >/dev/null && continue
	s=$(cat /sys/block/$d/device/serial | tr -d ' ')
	[ -z "$TESTDEV" ] || [ "$s" \< "$TESTSER" ] && { TESTDEV=$d; TESTSER=$s; }
done
say "GATE kver=$KVER testdev=$TESTDEV max_hw=$(cat /sys/block/$TESTDEV/queue/max_hw_sectors_kb)"
echo 2048 > /proc/sys/vm/nr_hugepages
MSK=/sys/block/$TESTDEV/queue/max_sectors_kb

run_case() {
	local name=$1 rep=$2; shift 2
	local json="$OUT/$KVER-$name-r$rep.json"
	fio --name="$name" --filename=/dev/$TESTDEV --direct=1 \
	    --ioengine=io_uring --time_based --runtime=20 --ramp_time=3 \
	    --norandommap --randrepeat=0 --group_reporting --size=100g \
	    --output-format=json --output="$json" "$@" >/dev/null 2>&1
	python3 - "$json" "$name" "$rep" <<'EOF' | tee -a "$LOG"
import json, sys
j = json.load(open(sys.argv[1])); job = j["jobs"][0]; r = job["read"]
print("RESULT case=%s rep=%s bw_MiBps=%.0f iops=%.0f p50_us=%.0f p99_us=%.0f "
      "usr=%.1f sys=%.1f" % (sys.argv[2], sys.argv[3],
      r["bw_bytes"]/(1<<20), r["iops"],
      r["clat_ns"]["percentile"]["50.000000"]/1e3,
      r["clat_ns"]["percentile"]["99.000000"]/1e3,
      job["usr_cpu"], job["sys_cpu"]))
EOF
}

# A) patched kernel, requests re-capped to 128KB via the admin knob
echo 128 > "$MSK"
say "PROBE max_sectors_kb=$(cat $MSK)"
for rep in 1 2 3; do
	run_case probe128_seq2m_qd8   $rep --bs=2M --rw=read     --iodepth=8  --numjobs=1 --iomem=mmaphuge
	run_case probe128_seq2m_qd32x4 $rep --bs=2M --rw=read    --iodepth=32 --numjobs=4 --offset_increment=25g --iomem=mmaphuge
	run_case probe128_rand1m_qd16 $rep --bs=1M --rw=randread --iodepth=16 --numjobs=1 --iomem=mmaphuge
	run_case probe128_rand512k_qd32 $rep --bs=512k --rw=randread --iodepth=32 --numjobs=1 --iomem=mmaphuge
done

# B) full-size requests, deeper queues
echo 2048 > "$MSK"
say "PROBE max_sectors_kb=$(cat $MSK)"
for rep in 1 2 3; do
	run_case probeqd_seq2m_qd16 $rep --bs=2M --rw=read --iodepth=16 --numjobs=1 --iomem=mmaphuge
	run_case probeqd_seq2m_qd64 $rep --bs=2M --rw=read --iodepth=64 --numjobs=1 --iomem=mmaphuge
	run_case probeqd_rand1m_qd64 $rep --bs=1M --rw=randread --iodepth=64 --numjobs=1 --iomem=mmaphuge
done
echo 2048 > "$MSK"
say "PROBE_DONE kver=$KVER"
