#!/bin/bash
# Host side (on the Latitude box): vng guests with emulated intel-iommu +
# RAM-backed emulated NVMe (mdts=10 => 4MB), guest kernels from /boot.
# Usage: remote-kvm-repro.sh smoke|matrix
set -u
export PATH=/root/.local/bin:$PATH
OUT=/root/iova/results
mkdir -p "$OUT"

deps() {
	export DEBIAN_FRONTEND=noninteractive
	command -v qemu-system-x86_64 >/dev/null || apt-get -qq install -y qemu-system-x86 >/dev/null
	command -v vng >/dev/null || { apt-get -qq install -y pipx >/dev/null; pipx install virtme-ng >/dev/null 2>&1; }
	command -v vng >/dev/null || { echo "FATAL: vng install failed"; exit 1; }
	if [ ! -f /dev/shm/nvme.img ]; then
		dd if=/dev/urandom of=/dev/shm/nvme.img bs=64M count=128 status=none
	fi
	ls -la /dev/kvm /dev/shm/nvme.img
}

QOPTS="-machine q35 -device intel-iommu -drive file=/dev/shm/nvme.img,if=none,format=raw,id=nvm,cache=unsafe -device nvme,serial=repro1,drive=nvm,mdts=10"

boot_one() {
	local kver=$1 msk=$2 tag=$3
	local log="$OUT/kvmrepro-$tag.log"
	timeout 600 vng --run "/boot/vmlinuz-$kver" -p 14 -m 8G --force-9p \
		--append "intel_iommu=on iommu.passthrough=0" \
		--qemu-opts="$QOPTS" \
		-- /root/iova/guest-kvm-bench.sh "$msk" >"$log" 2>&1
	grep -E '^(KVER=|GATE|RESULT|GUEST_BENCH_DONE|FATAL)' "$log" | sed "s/^/$tag /"
	grep -q GUEST_BENCH_DONE "$log" || { echo "$tag BOOT_OR_BENCH_FAILED"; tail -5 "$log"; }
}

case "${1:-smoke}" in
smoke)
	deps
	boot_one 7.2.0-rc1-iovabase "" smoke-base
	;;
matrix)
	for round in 1 2; do
		boot_one 7.2.0-rc1-iovabase   ""     base-r$round
		boot_one 7.2.0-rc1-iovaopt    ""     optdflt-r$round
		boot_one 7.2.0-rc1-iovaopt    4096   optin-r$round
		boot_one 7.2.0-rc1-iovapatch  ""     oldpatch-r$round
	done
	echo KVM_MATRIX_DONE
	;;
esac
