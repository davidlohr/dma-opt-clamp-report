#!/bin/bash
# Rerun ONLY the kv_qos case with correct fio option ordering (globals
# before the first --name), both phases, appending to the iovaopt log.
set -u
KVER=$(uname -r)
case "$KVER" in *iovaopt*) ;; *) echo "FATAL wrong kernel $KVER"; exit 1;; esac
OUT=/root/iova/results
LOG="$OUT/$KVER.log"
say() { echo "$@" | tee -a "$LOG"; }

TESTDEV=""
for ns in /sys/block/nvme*n1; do
	d=$(basename "$ns")
	[ "$(cat "$ns"/size)" -gt 3000000000 ] || continue
	lsblk -n "/dev/$d" | grep -q part && continue
	findmnt -S "/dev/$d" >/dev/null && continue
	s=$(cat /sys/block/$d/device/serial | tr -d ' ')
	if [ -z "$TESTDEV" ] || [ "$s" \< "$TESTSER" ]; then TESTDEV=$d; TESTSER=$s; fi
done
echo 2048 > /proc/sys/vm/nr_hugepages
MSKF=/sys/block/$TESTDEV/queue/max_sectors_kb

qos() {
	local phase=$1 rep=$2
	local json="$OUT/$KVER-$phase-kv_qos-r$rep.json"
	fio --filename=/dev/$TESTDEV --direct=1 --ioengine=io_uring \
	    --time_based --runtime=20 --ramp_time=3 --norandommap \
	    --randrepeat=0 --size=100g --output-format=json --output="$json" \
	    --name=qos_big --bs=2M --rw=randread --iodepth=8 --numjobs=4 --iomem=mmaphuge \
	    --name=qos_small --bs=4k --rw=randread --iodepth=16 --numjobs=2 \
	    >/dev/null 2>&1
	python3 - "$json" "$phase.kv_qos" "$rep" <<'EOF' | tee -a "$LOG"
import json, sys
j = json.load(open(sys.argv[1]))
for job in j["jobs"]:
    r = job["read"]
    if r["io_bytes"] == 0:
        continue
    print("RESULT case=%s job=%s rep=%s bw_MiBps=%.0f iops=%.0f p50_us=%.0f "
          "p99_us=%.0f sys=%.1f irq_per_gb=0" % (
          sys.argv[2], job["jobname"], sys.argv[3],
          r["bw_bytes"] / (1 << 20), r["iops"],
          r["clat_ns"]["percentile"]["50.000000"] / 1e3,
          r["clat_ns"]["percentile"]["99.000000"] / 1e3, job["sys_cpu"]))
EOF
}

echo 128 > "$MSKF"
say "QOSFIX PHASE dflt msk=$(cat $MSKF)"
for rep in 1 2 3; do qos dflt $rep; done
echo 2048 > "$MSKF"
say "QOSFIX PHASE opt msk=$(cat $MSKF)"
for rep in 1 2 3; do qos opt $rep; done
echo 128 > "$MSKF"
say "QOSFIX_DONE"
