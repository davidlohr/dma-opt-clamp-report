#!/bin/bash
# On the LOCK_STAT kernel: iova_rbtree_lock contention with 16-way >rcache
# traffic (opt-in) vs rcache traffic (default), then blktests block+nvme.
set -u
KVER=$(uname -r)
case "$KVER" in *iovaopt-ls*) ;; *) echo "FATAL wrong kernel $KVER"; exit 1;; esac
OUT=/root/iova/results; LOG=$OUT/lockstat.log; : > $LOG
say() { echo "$@" | tee -a "$LOG"; }
say "GATE kver=$KVER"

mapfile -t DRV < <(for ns in /sys/block/nvme*n1; do
	d=$(basename "$ns")
	[ "$(cat "$ns"/size)" -gt 3000000000 ] || continue
	lsblk -n "/dev/$d" | grep -q part && continue
	findmnt -S "/dev/$d" >/dev/null && continue
	echo "$(cat /sys/block/$d/device/serial | tr -d ' ') $d"
done | sort | awk '{print $2}')
A=${DRV[0]}; B=${DRV[1]:-$A}
say "GATE devA=$A devB=$B max_hw=$(cat /sys/block/$A/queue/max_hw_sectors_kb)"
echo 2048 > /proc/sys/vm/nr_hugepages

capture() { # capture iova lock stats after a run
	local tag=$1
	awk '/iova_rbtree_lock|&iovad->/{show=8} show { print; show-- }' /proc/lock_stat \
		| head -24 | sed "s/^/LOCKSTAT $tag /" | tee -a "$LOG"
}

bench16() {
	local tag=$1 msk=$2
	echo $msk > /sys/block/$A/queue/max_sectors_kb
	echo 0 > /proc/lock_stat          # clear
	echo 1 > /proc/sys/kernel/lock_stat
	local json=/tmp/ls-$tag.json
	fio --name=mix16 --filename=/dev/$A --direct=1 --ioengine=io_uring \
	    --time_based --runtime=60 --ramp_time=3 --norandommap --randrepeat=0 \
	    --group_reporting --size=100g --output-format=json --output=$json \
	    --rw=randread --bssplit=256k/25:512k/25:1m/25:2m/25 \
	    --iodepth=8 --numjobs=16 >/dev/null 2>&1
	echo 0 > /proc/sys/kernel/lock_stat
	python3 - $json $tag <<'EOF' | tee -a "$LOG"
import json, sys
j = json.load(open(sys.argv[1])); job = j["jobs"][0]; r = job["read"]
print("RESULT case=mix16_%s bw_MiBps=%.0f iops=%.0f p99_us=%.0f sys=%.1f" % (
    sys.argv[2], r["bw_bytes"]/(1<<20), r["iops"],
    r["clat_ns"]["percentile"]["99.000000"]/1e3, job["sys_cpu"]))
EOF
	capture "$tag"
}

bench16 optin 2048
bench16 dflt 128
echo 128 > /sys/block/$A/queue/max_sectors_kb

# ---- blktests on devB (destructive to devB - blank scratch drive) ----
say "BLKTESTS start"
export DEBIAN_FRONTEND=noninteractive
command -v gcc >/dev/null && true
[ -d /root/blktests ] || git clone -q https://github.com/osandov/blktests /root/blktests
cd /root/blktests && make -s -j8 >/dev/null 2>&1
cat > config <<EOF
TEST_DEVS=(/dev/$B)
EOF
timeout 2400 ./check block nvme 2>&1 | tail -40 | sed 's/^/BLKTESTS /' | tee -a "$LOG"
say "LOCKSTAT_PHASE_DONE"
