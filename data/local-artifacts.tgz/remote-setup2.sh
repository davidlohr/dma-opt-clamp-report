#!/bin/bash
# Resume after DKMS postinst failure: install kernels manually (bypassing
# /etc/kernel/postinst.d, whose dkms hook can't build bnxt_en on 7.2-rc1).
# In-tree bnxt_en serves the NIC; verify it exists before any reboot.
set -euxo pipefail
cd /root/iova/linux

install_manual() {
	local ver=$1
	test -e "/lib/modules/$ver/kernel/drivers/net/ethernet/broadcom/bnxt/bnxt_en.ko"* \
		|| { echo "FATAL: no in-tree bnxt_en for $ver"; exit 1; }
	cp -f arch/x86/boot/bzImage "/boot/vmlinuz-$ver"
	cp -f System.map "/boot/System.map-$ver"
	cp -f .config "/boot/config-$ver"
	update-initramfs -c -k "$ver" 2>&1 | tail -2
}

# kernel B (already compiled + modules_install done before the hook died)
install_manual 7.2.0-rc1-iovabase

# kernel A: apply the single patch, rebuild, install
if ! grep -q dma_max_mapping_size drivers/nvme/host/pci.c; then
	patch -p1 < ../0001-nvme-pci-lift-dma-opt-cap.patch
fi
make -s -j"$(nproc)" LOCALVERSION=-iovapatch
make -s -j"$(nproc)" LOCALVERSION=-iovapatch modules_install
install_manual 7.2.0-rc1-iovapatch

sed -i 's/^GRUB_DEFAULT=.*/GRUB_DEFAULT=saved/' /etc/default/grub
if ! grep -q 'iommu.passthrough=0' /etc/default/grub; then
	sed -i 's/^GRUB_CMDLINE_LINUX="\(.*\)"/GRUB_CMDLINE_LINUX="\1 amd_iommu=on iommu.passthrough=0"/' /etc/default/grub
fi
update-grub 2>&1 | tail -3
grub-set-default 0
grep -oP "menuentry '\K[^']+(?=')" /boot/grub/grub.cfg | grep -i iova
echo SETUP2_DONE
