#!/bin/bash
# Add virtio/9p guest support (builtin) to all three kernels so they can
# boot as vng guests. Tree state on entry: P1+P2 applied (iovaopt).
set -euxo pipefail
cd /root/iova/linux

scripts/config -e VIRTIO -e VIRTIO_MENU -e VIRTIO_PCI -e VIRTIO_PCI_LEGACY \
	-e VIRTIO_NET -e VIRTIO_BLK -e VIRTIO_CONSOLE -e VIRTIO_BALLOON \
	-e HW_RANDOM_VIRTIO -e NET_9P -e NET_9P_VIRTIO -e 9P_FS \
	-e 9P_FS_POSIX_ACL -e NET_CORE -e PCI_HOST_GENERIC \
	-e FUSE_FS -e VIRTIO_FS -e OVERLAY_FS -e TMPFS_POSIX_ACL
make -s olddefconfig
grep -E '^CONFIG_(9P_FS|NET_9P_VIRTIO|VIRTIO_PCI|VIRTIO_NET)=' .config

build_install() {
	local tag=$1
	make -s -j"$(nproc)" LOCALVERSION=-$tag
	make -s -j"$(nproc)" LOCALVERSION=-$tag modules_install >/dev/null
	cp -f arch/x86/boot/bzImage /boot/vmlinuz-7.2.0-rc1-$tag
}

# iovaopt (tree as-is: P1+P2)
build_install iovaopt
# base (revert P2, P1)
patch -R -p1 < ../0002-nvme-pci-default-cap.patch
patch -R -p1 < ../0001-block-max-default-sectors.patch
build_install iovabase
# old patch
patch -p1 < ../0001-nvme-pci-lift-dma-opt-cap.patch
build_install iovapatch
# restore tree to iovaopt state for reference
patch -R -p1 < ../0001-nvme-pci-lift-dma-opt-cap.patch
patch -p1 < ../0001-block-max-default-sectors.patch
patch -p1 < ../0002-nvme-pci-default-cap.patch
echo SETUP4_DONE
