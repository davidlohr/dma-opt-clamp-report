#!/bin/bash
# Build kernel C (iovaopt): base + reshaped 2-patch series.
# Tree currently has the old 358580 patch applied - revert it first.
set -euxo pipefail
cd /root/iova/linux

patch -R -p1 < ../0001-nvme-pci-lift-dma-opt-cap.patch
patch -p1 < ../0001-block-max-default-sectors.patch
patch -p1 < ../0002-nvme-pci-default-cap.patch

make -s -j"$(nproc)" LOCALVERSION=-iovaopt
make -s -j"$(nproc)" LOCALVERSION=-iovaopt modules_install

test -e "/lib/modules/7.2.0-rc1-iovaopt/kernel/drivers/net/ethernet/broadcom/bnxt/bnxt_en.ko"* \
	|| { echo "FATAL: no in-tree bnxt_en"; exit 1; }
cp -f arch/x86/boot/bzImage /boot/vmlinuz-7.2.0-rc1-iovaopt
cp -f System.map /boot/System.map-7.2.0-rc1-iovaopt
cp -f .config /boot/config-7.2.0-rc1-iovaopt
update-initramfs -c -k 7.2.0-rc1-iovaopt 2>&1 | tail -1
update-grub 2>&1 | tail -2
grep -oP "menuentry '\K[^']+(?=')" /boot/grub/grub.cfg | grep iovaopt
echo SETUP3_DONE
