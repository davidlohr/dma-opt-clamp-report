#!/bin/bash
# Gate + optional quick fio on the current bare-metal boot. Args: <label> [fio]
LABEL=${1:?}; DOFIO=${2:-}
OUT=/root/iova/results; mkdir -p $OUT
LOG=$OUT/gate-$LABEL.log; : > $LOG
say() { echo "$@" | tee -a "$LOG"; }
say "GATE label=$LABEL kver=$(uname -r)"
say "GATE cmdline=$(cat /proc/cmdline | grep -oE 'iommu[^ ]*|amd_iommu[^ ]*' | tr '\n' ' ')"
dmesg | grep -iE 'Default domain type|AMD-Vi: Interrupt' | head -2 | tee -a "$LOG"
TESTDEV=""
for ns in /sys/block/nvme*n1; do
	d=$(basename "$ns")
	[ "$(cat "$ns"/size)" -gt 3000000000 ] || continue
	lsblk -n "/dev/$d" | grep -q part && continue
	findmnt -S "/dev/$d" >/dev/null && continue
	s=$(cat /sys/block/$d/device/serial | tr -d ' ')
	if [ -z "$TESTDEV" ] || [ "$s" \< "$TESTSER" ]; then TESTDEV=$d; TESTSER=$s; fi
done
PCIDEV=$(readlink -f /sys/block/$TESTDEV/device/device | grep -oE '[0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-9]' | tail -1)
for g in /sys/kernel/iommu_groups/*/devices/$PCIDEV; do
	[ -e "$g" ] && say "GATE iommu_group_type=$(cat $(dirname $(dirname $g))/type)"
done
say "GATE testdev=$TESTDEV max_hw_sectors_kb=$(cat /sys/block/$TESTDEV/queue/max_hw_sectors_kb) max_sectors_kb=$(cat /sys/block/$TESTDEV/queue/max_sectors_kb)"
if [ "$DOFIO" = fio ]; then
	echo 1024 > /proc/sys/vm/nr_hugepages
	for rep in 1 2 3; do
		json=/tmp/gf-$rep.json
		fio --name=seq2m_qd8 --filename=/dev/$TESTDEV --direct=1 \
		    --ioengine=io_uring --time_based --runtime=15 --ramp_time=3 \
		    --size=100g --output-format=json --output=$json \
		    --bs=2M --rw=read --iodepth=8 --numjobs=1 --iomem=mmaphuge \
		    >/dev/null 2>&1
		python3 -c '
import json,sys
j=json.load(open(sys.argv[1])); r=j["jobs"][0]["read"]
print("RESULT case=ptseq2m rep=%s bw_MiBps=%.0f p99_us=%.0f" % (
    sys.argv[2], r["bw_bytes"]/(1<<20),
    r["clat_ns"]["percentile"]["99.000000"]/1e3))' $json $rep | tee -a "$LOG"
	done
fi
say "GATECHECK_DONE $LABEL"
