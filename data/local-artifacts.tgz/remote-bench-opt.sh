#!/bin/bash
# Validate the reshaped series on the iovaopt kernel:
#  gates: max_hw=2048 (ceiling lifted) AND max_sectors=128 (default kept)
#  phase dflt: key cases at default        -> expect == base kernel
#  phase opt : after max_sectors_kb=2048   -> expect == old patched kernel
set -u
KVER=$(uname -r)
case "$KVER" in *iovaopt*) ;; *) echo "FATAL wrong kernel $KVER"; exit 1;; esac
OUT=/root/iova/results
LOG="$OUT/$KVER.log"
: > "$LOG"
say() { echo "$@" | tee -a "$LOG"; }

TESTDEV=""
for ns in /sys/block/nvme*n1; do
	d=$(basename "$ns")
	[ "$(cat "$ns"/size)" -gt 3000000000 ] || continue
	lsblk -n "/dev/$d" | grep -q part && continue
	findmnt -S "/dev/$d" >/dev/null && continue
	s=$(cat /sys/block/$d/device/serial | tr -d ' ')
	if [ -z "$TESTDEV" ] || [ "$s" \< "$TESTSER" ]; then TESTDEV=$d; TESTSER=$s; fi
done
MHW=$(cat /sys/block/$TESTDEV/queue/max_hw_sectors_kb)
MSK=$(cat /sys/block/$TESTDEV/queue/max_sectors_kb)
say "GATE kver=$KVER testdev=$TESTDEV max_hw_sectors_kb=$MHW max_sectors_kb=$MSK"
[ "$MHW" = 2048 ] && [ "$MSK" = 128 ] || { say "FATAL gate mismatch"; exit 1; }
echo 2048 > /proc/sys/vm/nr_hugepages

irq_sum() { awk '/nvme/{for(i=2;i<NF-2;i++) s+=$i} END{print s+0}' /proc/interrupts; }

run_case() {
	local phase=$1 name=$2 rep=$3; shift 3
	local json="$OUT/$KVER-$phase-$name-r$rep.json"
	local i0 i1
	i0=$(irq_sum)
	fio --name="$name" --filename=/dev/$TESTDEV --direct=1 \
	    --ioengine=io_uring --time_based --runtime=20 --ramp_time=3 \
	    --norandommap --randrepeat=0 --size=100g \
	    --output-format=json --output="$json" "$@" >/dev/null 2>&1
	i1=$(irq_sum)
	python3 - "$json" "$phase.$name" "$rep" "$((i1-i0))" <<'EOF' | tee -a "$LOG"
import json, sys
j = json.load(open(sys.argv[1]))
irqs = int(sys.argv[4])
tot_gb = sum(job["read"]["io_bytes"] + job["write"]["io_bytes"]
             for job in j["jobs"]) / (1 << 30)
for job in j["jobs"]:
    for d in ("read", "write"):
        r = job[d]
        if r["io_bytes"] == 0:
            continue
        print("RESULT case=%s job=%s rep=%s bw_MiBps=%.0f iops=%.0f p50_us=%.0f "
              "p99_us=%.0f sys=%.1f irq_per_gb=%.0f" % (
              sys.argv[2], job["jobname"], sys.argv[3],
              r["bw_bytes"] / (1 << 20), r["iops"],
              r["clat_ns"]["percentile"]["50.000000"] / 1e3,
              r["clat_ns"]["percentile"]["99.000000"] / 1e3,
              job["sys_cpu"], irqs / tot_gb if tot_gb else 0))
EOF
}

phase_run() {
	local phase=$1
	for rep in 1 2 3; do
		run_case $phase seq2m_qd8 $rep --bs=2M --rw=read --iodepth=8 \
			--numjobs=1 --iomem=mmaphuge --group_reporting
		run_case $phase rand1m_qd16 $rep --bs=1M --rw=randread --iodepth=16 \
			--numjobs=1 --iomem=mmaphuge --group_reporting
		run_case $phase rand4k_qd32x8 $rep --bs=4k --rw=randread --iodepth=32 \
			--numjobs=8 --group_reporting
		run_case $phase kv_qos $rep \
			--name=qos_big --bs=2M --rw=randread --iodepth=8 --numjobs=4 --iomem=mmaphuge \
			--name=qos_small --bs=4k --rw=randread --iodepth=16 --numjobs=2
	done
}

say "PHASE dflt (max_sectors_kb=128 default)"
phase_run dflt

echo 2048 > /sys/block/$TESTDEV/queue/max_sectors_kb
say "PHASE opt (max_sectors_kb=2048 opt-in)"
phase_run opt
echo 128 > /sys/block/$TESTDEV/queue/max_sectors_kb

dmesg | grep -icE 'WARNING:|BUG:|Oops|Call Trace|DMAR|AMD-Vi.*(fault|error)' \
	| xargs -I{} say "DMESG_SCAN: {} findings"
say "BENCH_OPT_DONE kver=$KVER"
