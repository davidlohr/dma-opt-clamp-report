#!/bin/bash
# Build the LOCK_STAT diagnostic kernel (tree at P1+P2 state) with nvmet/null_blk
# modules for blktests.
set -euxo pipefail
cd /root/iova/linux
grep -q opt_transfer_sectors drivers/nvme/host/pci.c || { echo "FATAL tree not at P1+P2"; exit 1; }
scripts/config -e LOCK_STAT -e CONFIGFS_FS -m BLK_DEV_NULL_BLK \
	-m NVME_TARGET -m NVME_TARGET_LOOP -m NVME_FABRICS -m NVME_TCP
make -s olddefconfig
grep -E '^CONFIG_(LOCK_STAT|NVME_TARGET|BLK_DEV_NULL_BLK)=' .config
make -s -j"$(nproc)" LOCALVERSION=-iovaopt-ls
make -s -j"$(nproc)" LOCALVERSION=-iovaopt-ls modules_install >/dev/null
test -e "/lib/modules/7.2.0-rc1-iovaopt-ls/kernel/drivers/net/ethernet/broadcom/bnxt/bnxt_en.ko"* \
	|| { echo "FATAL: no bnxt_en"; exit 1; }
cp -f arch/x86/boot/bzImage /boot/vmlinuz-7.2.0-rc1-iovaopt-ls
cp -f System.map /boot/System.map-7.2.0-rc1-iovaopt-ls
cp -f .config /boot/config-7.2.0-rc1-iovaopt-ls
update-initramfs -c -k 7.2.0-rc1-iovaopt-ls 2>&1 | tail -1
update-grub 2>&1 | tail -1
echo SETUP5_DONE
