#!/bin/bash
# Runs INSIDE the vng guest on the box. Arg1: max_sectors_kb to set ("" = leave default).
MSK_SET=${1:-}
echo "KVER=$(uname -r)"
dmesg | grep -iE 'DMAR: IOMMU|DMAR: Intel|Default domain type' | head -3

DEV=""
for c in /sys/class/nvme/nvme*; do
	grep -q QEMU "$c/model" 2>/dev/null && DEV=$(basename "$c")
done
[ -n "$DEV" ] || { echo "FATAL: no QEMU nvme in guest"; exit 1; }
T=${DEV}n1
echo "GATE testdev=$T max_hw_sectors_kb=$(cat /sys/block/$T/queue/max_hw_sectors_kb) max_sectors_kb=$(cat /sys/block/$T/queue/max_sectors_kb)"
if [ -n "$MSK_SET" ]; then
	echo "$MSK_SET" > /sys/block/$T/queue/max_sectors_kb
	echo "GATE msk_now=$(cat /sys/block/$T/queue/max_sectors_kb)"
fi
echo 512 > /proc/sys/vm/nr_hugepages

run_case() {
	local name=$1 rep=$2; shift 2
	local json=/tmp/g-$name-r$rep.json
	fio --name="$name" --filename=/dev/$T --direct=1 --ioengine=io_uring \
	    --time_based --runtime=15 --ramp_time=3 --norandommap --randrepeat=0 \
	    --group_reporting --size=7g --output-format=json --output="$json" \
	    "$@" >/dev/null 2>&1
	python3 - "$json" "$name" "$rep" <<'EOF'
import json, sys
j = json.load(open(sys.argv[1])); job = j["jobs"][0]; r = job["read"]
print("RESULT case=%s rep=%s bw_MiBps=%.0f iops=%.0f p50_us=%.0f p99_us=%.0f "
      "sys=%.1f irq_per_gb=0" % (sys.argv[2], sys.argv[3],
      r["bw_bytes"]/(1<<20), r["iops"],
      r["clat_ns"]["percentile"]["50.000000"]/1e3,
      r["clat_ns"]["percentile"]["99.000000"]/1e3, job["sys_cpu"]))
EOF
}

for rep in 1 2 3; do
	run_case seq2m_qd8     $rep --bs=2M   --rw=read     --iodepth=8  --numjobs=1 --iomem=mmaphuge
	run_case rand512k_qd32 $rep --bs=512k --rw=randread --iodepth=32 --numjobs=1 --iomem=mmaphuge
	run_case rand4k_qd32x8 $rep --bs=4k   --rw=randread --iodepth=32 --numjobs=8
done
echo "GUEST_BENCH_DONE"
